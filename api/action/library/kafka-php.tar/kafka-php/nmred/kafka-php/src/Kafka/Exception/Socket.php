<?php

namespace Kafka\Exception;

use \Kafka\Exception;

class Socket extends Exception
{
}
