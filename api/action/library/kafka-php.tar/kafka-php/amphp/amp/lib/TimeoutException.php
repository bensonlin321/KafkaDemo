<?php

namespace Amp;

class TimeoutException extends \RuntimeException {}
